import os
import requests
import subprocess

# URLs and file names
EFFICIENTVIT_SAM_URL = "https://huggingface.co/han-cai/efficientvit-sam/resolve/main"
EFFICIENTVIT_SAM_MODEL = "xl1.pt"
REQUIREMENTS_FILE = "requirements.txt"

# Function to download model if not already present
def download(url, filename):
    if not os.path.exists(filename):
        print(f"Downloading {filename}...")
        response = requests.get(f"{url}/{filename}", stream=True)
        if response.status_code == 200:
            with open(filename, "wb") as f:
                f.write(response.content)
            print(f"{filename} downloaded successfully.")
        else:
            print(f"Failed to download {filename}.")
    else:
        print(f"{filename} already exists.")

# Function to install requirements
def setup():
    if os.path.exists(REQUIREMENTS_FILE):
        print("Installing requirements...")
        subprocess.check_call([os.sys.executable, "-m", "pip", "install", "-r", REQUIREMENTS_FILE])
    else:
        print(f"{REQUIREMENTS_FILE} not found.")

# Main function to replace make targets
if __name__ == "__main__":
    # Setup environment
    setup()

    # Download the model weights
    download(EFFICIENTVIT_SAM_URL, EFFICIENTVIT_SAM_MODEL)
