python3 main.py -c ./configs/a2d_sentences.yaml -rm test -ng 1 --version "a2d_test" --backbone "video-swin-b" \
-bpp "/mnt/data_16TB/lzy23/pretrained/pretrained_swin_transformer/swin_base_patch244_window877_kinetics400_22k.pth" \
-bs 2
